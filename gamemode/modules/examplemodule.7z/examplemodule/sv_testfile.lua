liro.diagnosticPrint("atleast one of them fucking loads")

   